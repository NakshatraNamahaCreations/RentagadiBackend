JWT_SECRET_KEY = "RENT_angadi123";

module.exports = JWT_SECRET_KEY;
